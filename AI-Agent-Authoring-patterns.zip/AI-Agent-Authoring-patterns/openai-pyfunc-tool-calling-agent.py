# Databricks notebook source
# MAGIC %md 
# MAGIC # Mosaic AI Agent Framework: Author and deploy a tool-calling OpenAI agent
# MAGIC
# MAGIC This notebook demonstrates how to author an OpenAI agent that's compatible with Mosaic AI Agent Framework features. In this notebook you learn to:
# MAGIC - Author a tool-calling OpenAI `ChatAgent`
# MAGIC - Manually test the agent's output
# MAGIC - Evaluate the agent using Mosaic AI Agent Evaluation
# MAGIC - Log and deploy the agent
# MAGIC
# MAGIC To learn more about authoring an agent using Mosaic AI Agent Framework, see Databricks documentation ([AWS](https://docs.databricks.com/aws/generative-ai/agent-framework/author-agent) | [Azure](https://learn.microsoft.com/azure/databricks/generative-ai/agent-framework/create-chat-model)).
# MAGIC
# MAGIC ## Prerequisites
# MAGIC
# MAGIC - Address all `TODO`s in this notebook.

# COMMAND ----------

# MAGIC %pip install -U -qqqq mlflow backoff openai databricks-openai unitycatalog-openai[databricks] pydantic databricks-agents uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ## Define the agent in code
# MAGIC Define the agent code in a single cell below. This lets you easily write the agent code to a local Python file, using the `%%writefile` magic command, for subsequent logging and deployment.
# MAGIC
# MAGIC #### Agent tools
# MAGIC This agent code adds the built-in Unity Catalog function `system.ai.python_exec` to the agent. The agent code also includes commented-out sample code for adding a vector search index to perform unstructured data retrieval.
# MAGIC
# MAGIC For more examples of tools to add to your agent, see Databricks documentation ([AWS](https://docs.databricks.com/aws/generative-ai/agent-framework/agent-tool) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/agent-framework/agent-tool))
# MAGIC

# COMMAND ----------

# MAGIC %%writefile agent.py
# MAGIC import json
# MAGIC from typing import Any, Callable, Dict, Generator, List, Optional
# MAGIC
# MAGIC import backoff
# MAGIC import mlflow
# MAGIC import openai
# MAGIC from databricks.sdk import WorkspaceClient
# MAGIC from databricks_openai import VectorSearchRetrieverTool
# MAGIC from mlflow.entities import SpanType
# MAGIC from mlflow.pyfunc import ChatAgent
# MAGIC from mlflow.types.agent import (
# MAGIC     ChatAgentChunk,
# MAGIC     ChatAgentMessage,
# MAGIC     ChatAgentResponse,
# MAGIC     ChatContext,
# MAGIC )
# MAGIC from openai import OpenAI
# MAGIC from pydantic import BaseModel
# MAGIC from unitycatalog.ai.core.databricks import DatabricksFunctionClient
# MAGIC from unitycatalog.ai.openai.toolkit import UCFunctionToolkit
# MAGIC
# MAGIC mlflow.openai.autolog()
# MAGIC
# MAGIC ############################################
# MAGIC # Define your LLM endpoint and system prompt
# MAGIC ############################################
# MAGIC # TODO: Replace with your model serving endpoint
# MAGIC LLM_ENDPOINT_NAME = "databricks-meta-llama-3-3-70b-instruct"
# MAGIC
# MAGIC # TODO: Update with your system prompt
# MAGIC SYSTEM_PROMPT = """
# MAGIC You are a helpful assistant. You can assist with stock market analysis, technical analysis, and other financial topics.
# MAGIC """
# MAGIC
# MAGIC
# MAGIC ###############################################################################
# MAGIC ## Define tools for your agent, enabling it to retrieve data or take actions
# MAGIC ## beyond text generation
# MAGIC ## To create and see usage examples of more tools, see
# MAGIC ## https://docs.databricks.com/en/generative-ai/agent-framework/agent-tool.html
# MAGIC ###############################################################################
# MAGIC class ToolInfo(BaseModel):
# MAGIC     name: str
# MAGIC     spec: dict
# MAGIC     exec_fn: Callable
# MAGIC
# MAGIC
# MAGIC TOOL_INFOS = []
# MAGIC
# MAGIC # You can use UDFs in Unity Catalog as agent tools
# MAGIC # Below, we add the `system.ai.python_exec` UDF, which provides
# MAGIC # a python code interpreter tool to our agent
# MAGIC
# MAGIC # TODO: Add additional tools
# MAGIC UC_TOOL_NAMES = ["system.ai.python_exec"]
# MAGIC uc_tool_client = DatabricksFunctionClient()
# MAGIC
# MAGIC uc_toolkit = UCFunctionToolkit(function_names=UC_TOOL_NAMES, client=uc_tool_client)
# MAGIC for tool_spec in uc_toolkit.tools:
# MAGIC     tool_name = tool_spec["function"]["name"]
# MAGIC     udf_name = tool_name.replace("__", ".")
# MAGIC
# MAGIC     # Define a wrapper that accepts kwargs for the UC tool call,
# MAGIC     # then passes them to the UC tool execution client
# MAGIC     def execute_uc_tool(**kwargs):
# MAGIC         function_result = uc_tool_client.execute_function(udf_name, kwargs)
# MAGIC         if function_result.error is not None:
# MAGIC             return function_result.error
# MAGIC         else:
# MAGIC             return function_result.value
# MAGIC
# MAGIC     TOOL_INFOS.append(ToolInfo(name=tool_name, spec=tool_spec, exec_fn=execute_uc_tool))
# MAGIC
# MAGIC # Use Databricks vector search indexes as tools
# MAGIC # See https://docs.databricks.com/en/generative-ai/agent-framework/unstructured-retrieval-tools.html#locally-develop-vector-search-retriever-tools-with-ai-bridge
# MAGIC # for details
# MAGIC VECTOR_SEARCH_TOOLS = []
# MAGIC
# MAGIC # TODO: Add vector search indexes
# MAGIC # VECTOR_SEARCH_TOOLS.append(
# MAGIC #     VectorSearchRetrieverTool(
# MAGIC #         index_name="",
# MAGIC #         # filters="..."
# MAGIC #     )
# MAGIC # )
# MAGIC for vs_tool in VECTOR_SEARCH_TOOLS:
# MAGIC     tool_exec_fn = mlflow.trace(vs_tool.execute, span_type=SpanType.RETRIEVER)
# MAGIC     TOOL_INFOS.append(
# MAGIC         ToolInfo(
# MAGIC             name=vs_tool.tool["function"]["name"],
# MAGIC             spec=vs_tool.tool,
# MAGIC             exec_fn=tool_exec_fn,
# MAGIC         )
# MAGIC     )
# MAGIC
# MAGIC
# MAGIC class ToolCallingAgent(ChatAgent):
# MAGIC     """
# MAGIC     Class representing a tool-calling Agent
# MAGIC     """
# MAGIC
# MAGIC     def get_tool_specs(self):
# MAGIC         """
# MAGIC         Returns tool specifications in the format OpenAI expects.
# MAGIC         """
# MAGIC         return [tool_info.spec for tool_info in self._tools_dict.values()]
# MAGIC
# MAGIC     @mlflow.trace(span_type=SpanType.TOOL)
# MAGIC     def execute_tool(self, tool_name: str, args: dict) -> Any:
# MAGIC         """
# MAGIC         Executes the specified tool with the given arguments.
# MAGIC
# MAGIC         Args:
# MAGIC             tool_name (str): The name of the tool to execute.
# MAGIC             args (dict): Arguments for the tool.
# MAGIC
# MAGIC         Returns:
# MAGIC             Any: The tool's output.
# MAGIC         """
# MAGIC         if tool_name not in self._tools_dict:
# MAGIC             raise ValueError(f"Unknown tool: {tool_name}")
# MAGIC         return self._tools_dict[tool_name].exec_fn(**args)
# MAGIC
# MAGIC     def __init__(self, llm_endpoint: str, tools: Dict[str, Dict[str, Any]]):
# MAGIC         """
# MAGIC         Initializes the ToolCallingAgent with tools.
# MAGIC
# MAGIC         Args:
# MAGIC             tools (Dict[str, Dict[str, Any]]): A dictionary where each key is a tool name,
# MAGIC             and the value is a dictionary containing:
# MAGIC                 - "spec" (dict): JSON description of the tool (matches OpenAI format)
# MAGIC                 - "function" (Callable): Function that implements the tool logic
# MAGIC         """
# MAGIC         super().__init__()
# MAGIC         self.llm_endpoint = llm_endpoint
# MAGIC         self.workspace_client = WorkspaceClient()
# MAGIC         self.model_serving_client: OpenAI = (
# MAGIC             self.workspace_client.serving_endpoints.get_open_ai_client()
# MAGIC         )
# MAGIC         self._tools_dict = {
# MAGIC             tool.name: tool for tool in tools
# MAGIC         }  # Store tools for later execution
# MAGIC
# MAGIC     @mlflow.trace(span_type=SpanType.AGENT)
# MAGIC     def predict(
# MAGIC         self,
# MAGIC         messages: List[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> ChatAgentResponse:
# MAGIC         """
# MAGIC         Primary function that takes a user's request and generates a response.
# MAGIC         """
# MAGIC         # NOTE: this assumes that each chunk streamed by self.call_and_run_tools contains
# MAGIC         # a full message (i.e. chunk.delta is a complete message).
# MAGIC         # This is simple to implement, but you can also stream partial response messages from predict_stream,
# MAGIC         # and aggregate them in predict_stream by message ID
# MAGIC         response_messages = [
# MAGIC             chunk.delta
# MAGIC             for chunk in self.predict_stream(messages, context, custom_inputs)
# MAGIC         ]
# MAGIC         return ChatAgentResponse(messages=response_messages)
# MAGIC
# MAGIC     @mlflow.trace(span_type=SpanType.AGENT)
# MAGIC     def predict_stream(
# MAGIC         self,
# MAGIC         messages: List[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> Generator[ChatAgentChunk, None, None]:
# MAGIC         if len(messages) == 0:
# MAGIC             raise ValueError(
# MAGIC                 "The list of `messages` passed to predict(...) must contain at least one message"
# MAGIC             )
# MAGIC         all_messages = [
# MAGIC             ChatAgentMessage(role="system", content=SYSTEM_PROMPT)
# MAGIC         ] + messages
# MAGIC
# MAGIC         try:
# MAGIC             for message in self.call_and_run_tools(messages=all_messages):
# MAGIC                 yield ChatAgentChunk(delta=message)
# MAGIC         except openai.BadRequestError as e:
# MAGIC             error_data = getattr(e, "response", {}).get("json", lambda: None)()
# MAGIC             if error_data and "external_model_message" in error_data:
# MAGIC                 external_error = error_data["external_model_message"].get("error", {})
# MAGIC                 if external_error.get("code") == "content_filter":
# MAGIC                     return ChatAgentResponse(
# MAGIC                         messages=[
# MAGIC                             ChatAgentMessage(
# MAGIC                                 role="assistant",
# MAGIC                                 content="I'm sorry, I can't respond to that request.",
# MAGIC                             )
# MAGIC                         ]
# MAGIC                     )
# MAGIC             raise  # Re-raise if it's not a content filter error
# MAGIC
# MAGIC     @backoff.on_exception(backoff.expo, openai.RateLimitError)
# MAGIC     def chat_completion(self, messages: List[ChatAgentMessage]) -> ChatAgentResponse:
# MAGIC         return self.model_serving_client.chat.completions.create(
# MAGIC             model=self.llm_endpoint,
# MAGIC             messages=self._convert_messages_to_dict(messages),
# MAGIC             tools=self.get_tool_specs(),
# MAGIC         )
# MAGIC
# MAGIC     @mlflow.trace(span_type=SpanType.AGENT)
# MAGIC     def call_and_run_tools(
# MAGIC         self, messages, max_iter=10
# MAGIC     ) -> Generator[ChatAgentMessage, None, None]:
# MAGIC         current_msg_history = messages.copy()
# MAGIC         for i in range(max_iter):
# MAGIC             with mlflow.start_span(span_type="AGENT", name=f"iteration_{i + 1}"):
# MAGIC                 # Get an assistant response from the model, add it to the running history
# MAGIC                 # and yield it to the caller
# MAGIC                 # NOTE: we perform a simple non-streaming chat completions here
# MAGIC                 # Use the streaming API if you'd like to additionally do token streaming
# MAGIC                 # of agent output.
# MAGIC                 response = self.chat_completion(messages=current_msg_history)
# MAGIC                 llm_message = response.choices[0].message
# MAGIC                 assistant_message = ChatAgentMessage(**llm_message.to_dict())
# MAGIC                 current_msg_history.append(assistant_message)
# MAGIC                 yield assistant_message
# MAGIC
# MAGIC                 tool_calls = assistant_message.tool_calls
# MAGIC                 if not tool_calls:
# MAGIC                     return  # Stop streaming if no tool calls are needed
# MAGIC
# MAGIC                 # Execute tool calls, add them to the running message history,
# MAGIC                 # and yield their results as tool messages
# MAGIC                 for tool_call in tool_calls:
# MAGIC                     function = tool_call.function
# MAGIC                     args = json.loads(function.arguments)
# MAGIC                     # Cast tool result to a string, since not all tools return as tring
# MAGIC                     result = str(self.execute_tool(tool_name=function.name, args=args))
# MAGIC                     tool_call_msg = ChatAgentMessage(
# MAGIC                         role="tool", name=function.name, tool_call_id=tool_call.id, content=result
# MAGIC                     )
# MAGIC                     current_msg_history.append(tool_call_msg)
# MAGIC                     yield tool_call_msg
# MAGIC
# MAGIC         yield ChatAgentMessage(
# MAGIC            content=f"I'm sorry, I couldn't determine the answer after trying {max_iter} times.",
# MAGIC            role="assistant",
# MAGIC         )
# MAGIC
# MAGIC
# MAGIC
# MAGIC # Log the model using MLflow
# MAGIC AGENT = ToolCallingAgent(llm_endpoint=LLM_ENDPOINT_NAME, tools=TOOL_INFOS)
# MAGIC mlflow.models.set_model(AGENT)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test the agent
# MAGIC
# MAGIC Interact with the agent to test its output. Since we manually traced methods within `ChatAgent`, you can view the trace for each step the agent takes, with any LLM calls made via the OpenAI SDK automatically traced by autologging.
# MAGIC
# MAGIC Replace this placeholder input with an appropriate domain-specific example for your agent.

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from agent import AGENT

AGENT.predict(
    {"messages": [{"role": "user", "content": "Hello! What is 4*3 in Python?"}]}
)

# COMMAND ----------

for chunk in AGENT.predict_stream(
    {
        "messages": [
            {"role": "user", "content": "Tell me something cool about Databricks. Use your tools"},
        ]
    }
):
    print(chunk.delta)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Log the agent as an MLflow model
# MAGIC
# MAGIC Log the agent as code from the `agent.py` file. See [MLflow - Models from Code](https://mlflow.org/docs/latest/models.html#models-from-code).
# MAGIC
# MAGIC ### Enable automatic authentication for Databricks resources
# MAGIC For the most common Databricks resource types, Databricks supports and recommends declaring resource dependencies for the agent upfront during logging. This enables automatic authentication passthrough when you deploy the agent. With automatic authentication passthrough, Databricks automatically provisions, rotates, and manages short-lived credentials to securely access these resource dependencies from within the agent endpoint.
# MAGIC
# MAGIC To enable automatic authentication, specify the dependent Databricks resources when calling `mlflow.pyfunc.log_model().`
# MAGIC
# MAGIC   - **TODO**: If your Unity Catalog tool queries a [vector search index](docs link) or leverages [external functions](docs link), you need to include the dependent vector search index and UC connection objects, respectively, as resources. See docs ([AWS](https://docs.databricks.com/generative-ai/agent-framework/log-agent.html#specify-resources-for-automatic-authentication-passthrough) | [Azure](https://learn.microsoft.com/azure/databricks/generative-ai/agent-framework/log-agent#resources)).
# MAGIC
# MAGIC

# COMMAND ----------

# Determine Databricks resources to specify for automatic auth passthrough at deployment time
from agent import LLM_ENDPOINT_NAME, UC_TOOL_NAMES, VECTOR_SEARCH_TOOLS
import mlflow
from mlflow.models.resources import DatabricksFunction, DatabricksServingEndpoint

resources = [DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT_NAME)]
for tool in VECTOR_SEARCH_TOOLS:
    resources.extend(tool.resources)
for tool_name in UC_TOOL_NAMES:
    resources.append(DatabricksFunction(function_name=tool_name))

with mlflow.start_run():
    logged_agent_info = mlflow.pyfunc.log_model(
        artifact_path="agent",
        python_model="agent.py",
        pip_requirements=[
            "mlflow",
            "backoff",
            "openai",
            "databricks-openai",
            "pydantic",
            "unitycatalog-openai[databricks]",
        ],
        resources=resources,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Evaluate the agent with Agent Evaluation
# MAGIC
# MAGIC Use Mosaic AI Agent Evaluation to evalaute the agent's responses based on expected responses and other evaluation criteria. Use the evaluation criteria you specify to guide iterations, using MLflow to track the computed quality metrics.
# MAGIC See Databricks documentation ([AWS]((https://docs.databricks.com/aws/generative-ai/agent-evaluation) | [Azure](https://learn.microsoft.com/azure/databricks/generative-ai/agent-evaluation/)).
# MAGIC
# MAGIC
# MAGIC To evaluate your tool calls, add custom metrics. See Databricks documentation ([AWS](https://docs.databricks.com/en/generative-ai/agent-evaluation/custom-metrics.html#evaluating-tool-calls) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/agent-evaluation/custom-metrics#evaluating-tool-calls)).

# COMMAND ----------

import pandas as pd

eval_examples = [
    {
        "request": {"messages": [{"role": "user", "content": "What is an LLM agent?"}]},
        "expected_response": None,
    }
]

eval_dataset = pd.DataFrame(eval_examples)
display(eval_dataset)

# COMMAND ----------

import mlflow

with mlflow.start_run(run_id=logged_agent_info.run_id):
    eval_results = mlflow.evaluate(
        f"runs:/{logged_agent_info.run_id}/agent",
        data=eval_dataset,  # Your evaluation dataset
        model_type="databricks-agent",  # Enable Mosaic AI Agent Evaluation
    )

# Review the evaluation results in the MLFLow UI (see console output), or access them in place:
display(eval_results.tables["eval_results"])

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Pre-deployment agent validation
# MAGIC Before registering and deploying the agent, perform pre-deployment checks using the [mlflow.models.predict()](https://mlflow.org/docs/latest/python_api/mlflow.models.html#mlflow.models.predict) API. See Databricks documentation ([AWS](https://docs.databricks.com/en/machine-learning/model-serving/model-serving-debug.html#validate-inputs) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/machine-learning/model-serving/model-serving-debug#before-model-deployment-validation-checks)).

# COMMAND ----------

mlflow.models.predict(
    model_uri=f"runs:/{logged_agent_info.run_id}/agent",
    input_data={"messages": [{"role": "user", "content": "Hello!"}]},
    env_manager="uv",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Register the model to Unity Catalog
# MAGIC
# MAGIC Before you deploy the agent, you must register the agent to Unity Catalog.
# MAGIC
# MAGIC - **TODO** Update the `catalog`, `schema`, and `model_name` below to register the MLflow model to Unity Catalog.

# COMMAND ----------

mlflow.set_registry_uri("databricks-uc")

# TODO: define the catalog, schema, and model name for your UC model
catalog = "sarbanimaiti_catalog"
schema = "dbdemo_agent"
model_name = "openai_pyfunc_tc_agent"
UC_MODEL_NAME = f"{catalog}.{schema}.{model_name}"

# register the model to UC
uc_registered_model_info = mlflow.register_model(model_uri=logged_agent_info.model_uri, name=UC_MODEL_NAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Deploy the agent

# COMMAND ----------

from databricks import agents
agents.deploy(UC_MODEL_NAME, uc_registered_model_info.version, tags = {"endpointSource": "docs"})

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next steps
# MAGIC
# MAGIC After your agent is deployed, you can chat with it in AI playground to perform additional checks, share it with SMEs in your organization for feedback, or embed it in a production application. See docs ([AWS](https://docs.databricks.com/en/generative-ai/deploy-agent.html) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/deploy-agent)) for details