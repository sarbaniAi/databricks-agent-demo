# Databricks notebook source
# MAGIC %md 
# MAGIC # How to build a LangGraph agent using Mosaic AI Agent Framework 
# MAGIC
# MAGIC This notebook demonstrates how to author a LangGraph agent that's compatible with Mosaic AI Agent Framework features. In this notebook you learn to:
# MAGIC - Author a tool-calling LangGraph agent wrapped with `ChatAgent` with custom inputs and outputs
# MAGIC - Manually test the agent's output
# MAGIC - Log and deploy the agent
# MAGIC
# MAGIC To learn more about authoring an agent using Mosaic AI Agent Framework, see Databricks documentation ([AWS](https://docs.databricks.com/aws/generative-ai/agent-framework/author-agent) | [Azure](https://learn.microsoft.com/azure/databricks/generative-ai/agent-framework/create-chat-model)).
# MAGIC
# MAGIC ## Prerequisites
# MAGIC
# MAGIC - Address all `TODO`s in this notebook.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### USE CASE: AI-driven Financial Analyst
# MAGIC Our AI-driven Financial Analyst is designed to assist with various financial transactions and analyses. This intelligent agent can perform two primary functions:
# MAGIC
# MAGIC Financial Calculations: The agent can execute Python code to perform a wide range of financial calculations, from simple interest computations to complex investment analyses.
# MAGIC
# MAGIC Email Analysis for Fraud Detection: The agent can scan through customer emails to identify important communications related to financial transactions, particularly focusing on potential fraudulent activities or confirming legitimate transactions that were initially flagged as suspicious.

# COMMAND ----------

# MAGIC %pip install -U -qqqq mlflow langchain langgraph==0.2.74 unitycatalog-langchain[databricks] databricks-langchain pydantic databricks-agents uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------


# catalog = "sarbanimaiti_catalog"
# schema = dbName = db = "dbdemos_fsi_fraud_detection"

# spark.sql(f"USE CATALOG {catalog}")
# spark.sql(f"USE SCHEMA {schema}")

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ## Define the agent in code 
# MAGIC ([MLFLOW - Model From Code GUIDE](https://mlflow.org/docs/latest/model/models-from-code.html))
# MAGIC Define the agent code in a single cell below. This lets you easily write the agent code to a local Python file, using the `%%writefile` magic command, for subsequent logging and deployment.
# MAGIC
# MAGIC #### Agent tools
# MAGIC This agent code adds the built-in Unity Catalog function `system.ai.python_exec` to the agent. The agent code also includes commented-out sample code for adding a vector search index to perform unstructured data retrieval.
# MAGIC
# MAGIC For more examples of tools to add to your agent, see Databricks documentation ([AWS](https://docs.databricks.com/aws/generative-ai/agent-framework/agent-tool) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/agent-framework/agent-tool))
# MAGIC
# MAGIC #### Wrap the LangGraph agent using the `ChatAgent` interface
# MAGIC
# MAGIC For compatibility with Databricks AI features, the `LangGraphChatAgent` class implements the `ChatAgent` interface to wrap the LangGraph agent. This example uses the provided convenience APIs [`ChatAgentState`](https://mlflow.org/docs/latest/python_api/mlflow.langchain.html#mlflow.langchain.chat_agent_langgraph.ChatAgentState) and [`ChatAgentToolNode`](https://mlflow.org/docs/latest/python_api/mlflow.langchain.html#mlflow.langchain.chat_agent_langgraph.ChatAgentToolNode) for ease of use.
# MAGIC
# MAGIC Databricks recommends using `ChatAgent` as it simplifies authoring multi-turn conversational agents using an open source standard. See MLflow's [ChatAgent documentation](https://mlflow.org/docs/latest/python_api/mlflow.pyfunc.html#mlflow.pyfunc.ChatAgent).
# MAGIC
# MAGIC
# MAGIC **Authoring your agent using ChatAgent provides the following benefits:**
# MAGIC
# MAGIC - **Advanced agent capabilities**
# MAGIC > - **Streaming output**: Enable interactive user experiences by streaming output in smaller chunks.
# MAGIC > - **Comprehensive tool-calling message history**: Return multiple messages, including intermediate tool-calling messages, for improved quality and conversation management.
# MAGIC > - **Tool-calling confirmation suppor**t
# MAGIC > - **Multi-agent system support**
# MAGIC
# MAGIC **Streamlined development, deployment, and monitoring**
# MAGIC > - **Databricks feature integration**: Out-of-the-box compatibility with AI Playground, Agent Evaluation, and Agent Monitoring.
# MAGIC > - **Typed authoring interfaces**: Write agent code using typed Python classes, benefiting from IDE and notebook autocomplete.
# MAGIC > - **Automatic signature inference**: MLflow automatically infers ChatAgent signatures when logging the agent, simplifying registration and deployment. See Infer Model Signature during logging.
# MAGIC > - **AI Gateway-enhanced inference tables**: AI Gateway inference tables are automatically enabled for deployed agents, providing access to detailed request log metadata.
# MAGIC
# MAGIC
# MAGIC #### Custom inputs and outputs
# MAGIC
# MAGIC Some scenarios may require additional agent inputs, such as client_type and session_id, or outputs like retrieval source links that should not be included in the chat history for future interactions.
# MAGIC
# MAGIC For these scenarios, MLflow ChatAgent natively supports the fields custom_inputs and custom_outputs.
# MAGIC The agent is designed to handle custom inputs and outputs using the `predict` methods and the `add_custom_outputs` function.
# MAGIC
# MAGIC - In the `predict` and `predict_stream` methods of the `LangGraphChatAgent` class:
# MAGIC     - Custom inputs are passed as an optional parameter and included in the request dictionary.
# MAGIC     - Custom outputs are captured from the agent's response and added to the `ChatAgentResponse` object.
# MAGIC
# MAGIC - In the `add_custom_outputs` function:
# MAGIC     - This function is added as a node in the agent's workflow to append custom outputs to the state before returning the final response.

# COMMAND ----------

# MAGIC %%writefile agent.py
# MAGIC from typing import Any, Generator, Optional, Sequence, Union
# MAGIC
# MAGIC import mlflow
# MAGIC from databricks_langchain import ChatDatabricks, VectorSearchRetrieverTool
# MAGIC from databricks_langchain.uc_ai import (
# MAGIC     DatabricksFunctionClient,
# MAGIC     UCFunctionToolkit,
# MAGIC     set_uc_function_client,
# MAGIC )
# MAGIC from langchain_core.language_models import LanguageModelLike
# MAGIC from langchain_core.runnables import RunnableConfig, RunnableLambda
# MAGIC from langchain_core.tools import BaseTool
# MAGIC from langgraph.graph import END, StateGraph
# MAGIC from langgraph.graph.graph import CompiledGraph
# MAGIC from langgraph.graph.state import CompiledStateGraph
# MAGIC from langgraph.prebuilt.tool_executor import ToolExecutor
# MAGIC from mlflow.langchain.chat_agent_langgraph import ChatAgentState, ChatAgentToolNode
# MAGIC from mlflow.pyfunc import ChatAgent
# MAGIC from mlflow.types.agent import (
# MAGIC     ChatAgentChunk,
# MAGIC     ChatAgentMessage,
# MAGIC     ChatAgentResponse,
# MAGIC     ChatContext,
# MAGIC )
# MAGIC
# MAGIC mlflow.langchain.autolog()
# MAGIC
# MAGIC client = DatabricksFunctionClient()
# MAGIC set_uc_function_client(client)
# MAGIC
# MAGIC ############################################
# MAGIC # Define your LLM endpoint and system prompt
# MAGIC ############################################
# MAGIC # TODO: Replace with your model serving endpoint
# MAGIC LLM_ENDPOINT_NAME =  "agents-demo-gpt4o"
# MAGIC llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME)
# MAGIC
# MAGIC
# MAGIC # TODO: Update with your system prompt
# MAGIC system_prompt = """
# MAGIC You are a helpful assistant. You can assist with Financial calculations and customer email analysis for financial transactions.
# MAGIC Use tool "system.ai.python_exec" for running python code to perform any financial calculation.
# MAGIC Use tool "sarbanimaiti_catalog.dbdemos_fsi_fraud_detection.cust_emails" to extract customer emails reporting any fraudulent transactions or emails confirming legitimate transactions that were initially flagged as suspicious. These emails will be used  for fraud analysis & investigation
# MAGIC """
# MAGIC
# MAGIC ###############################################################################
# MAGIC ## Define tools for your agent, enabling it to retrieve data or take actions
# MAGIC ## beyond text generation
# MAGIC ## To create and see usage examples of more tools, see
# MAGIC ## https://docs.databricks.com/en/generative-ai/agent-framework/agent-tool.html
# MAGIC ###############################################################################
# MAGIC tools = []
# MAGIC
# MAGIC # You can use UDFs in Unity Catalog as agent tools
# MAGIC # Below, we add the `system.ai.python_exec` UDF, which provides
# MAGIC # a python code interpreter tool to our agent
# MAGIC
# MAGIC # TODO: Add additional tools
# MAGIC uc_tool_names = ["system.ai.python_exec"]
# MAGIC uc_toolkit = UCFunctionToolkit(function_names=uc_tool_names)
# MAGIC tools.extend(uc_toolkit.tools)
# MAGIC
# MAGIC # Use Databricks vector search indexes as tools
# MAGIC # See https://docs.databricks.com/en/generative-ai/agent-framework/unstructured-retrieval-tools.html#locally-develop-vector-search-retriever-tools-with-ai-bridge
# MAGIC # for details
# MAGIC
# MAGIC # TODO: Add vector search indexes : I am adding my own Vector Search Retriever Tool 
# MAGIC # (Search with customer name :'Steven Marshall'  or Transaction id 'cd506e3e-4809-45dc-b5b9-debfe70cf2f4')
# MAGIC
# MAGIC # vector_search_tools = [
# MAGIC #         VectorSearchRetrieverTool(
# MAGIC #         index_name="",
# MAGIC #         # filters="..."
# MAGIC #     )
# MAGIC # ]
# MAGIC vector_search_tools = [
# MAGIC         VectorSearchRetrieverTool(
# MAGIC         index_name="sarbanimaiti_catalog.dbdemos_fsi_fraud_detection.cust_emails_idx",
# MAGIC         # filters="..."
# MAGIC         query_type="HYBRID", # Query type ("ANN" or "HYBRID").
# MAGIC         tool_name="cust_emails", # Used by the LLM to understand the purpose of the tool
# MAGIC         tool_description="Use this tool to extract customer emails reporting fraudulent transactions or emails confirming legitimate transactions that were initially flagged as suspicious. These emails will be used  for fraud analysis & investigation", # Used by the LLM to understand the purpose of the tool
# MAGIC     )
# MAGIC ]
# MAGIC tools.extend(vector_search_tools)
# MAGIC
# MAGIC #####################
# MAGIC ## Define agent logic
# MAGIC #####################
# MAGIC
# MAGIC
# MAGIC def create_tool_calling_agent(
# MAGIC     model: LanguageModelLike,
# MAGIC     tools: Union[ToolExecutor, Sequence[BaseTool]],
# MAGIC     agent_prompt: Optional[str] = None,
# MAGIC ) -> CompiledGraph:
# MAGIC     model = model.bind_tools(tools)
# MAGIC
# MAGIC     # Define the function that determines which node to go to
# MAGIC     def should_continue(state: ChatAgentState):
# MAGIC         messages = state["messages"]
# MAGIC         last_message = messages[-1]
# MAGIC         # If there are function calls, continue. else, end
# MAGIC         if last_message.get("tool_calls"):
# MAGIC             return "continue"
# MAGIC         else:
# MAGIC             return "end"
# MAGIC
# MAGIC     if agent_prompt:
# MAGIC         preprocessor = RunnableLambda(
# MAGIC             lambda state: [{"role": "system", "content": agent_prompt}]
# MAGIC             + state["messages"]
# MAGIC         )
# MAGIC     else:
# MAGIC         preprocessor = RunnableLambda(lambda state: state["messages"])
# MAGIC     model_runnable = preprocessor | model
# MAGIC
# MAGIC     def call_model(
# MAGIC         state: ChatAgentState,
# MAGIC         config: RunnableConfig,
# MAGIC     ):
# MAGIC         response = model_runnable.invoke(state, config)
# MAGIC
# MAGIC         return {"messages": [response]}
# MAGIC
# MAGIC     def add_custom_outputs(state: ChatAgentState):
# MAGIC         # TODO: Return extra content with the custom_outputs key before returning
# MAGIC         return {
# MAGIC             "messages": [{"role": "assistant", "content": "Adding custom outputs"}],
# MAGIC             "custom_outputs": {
# MAGIC                 **(state.get("custom_outputs") or {}),
# MAGIC                 **(state.get("custom_inputs") or {}),
# MAGIC                 "key": "value",
# MAGIC             }, 
# MAGIC         }
# MAGIC
# MAGIC
# MAGIC     workflow = StateGraph(ChatAgentState)
# MAGIC
# MAGIC     workflow.add_node("agent", RunnableLambda(call_model))
# MAGIC     workflow.add_node("tools", ChatAgentToolNode(tools))
# MAGIC     workflow.add_node("add_custom_outputs", RunnableLambda(add_custom_outputs))
# MAGIC
# MAGIC     workflow.set_entry_point("agent")
# MAGIC     workflow.add_conditional_edges(
# MAGIC         "agent",
# MAGIC         should_continue,
# MAGIC         {
# MAGIC             "continue": "tools",
# MAGIC             "end": "add_custom_outputs",
# MAGIC         },
# MAGIC     )
# MAGIC     workflow.add_edge("tools", "agent")
# MAGIC     workflow.add_edge("add_custom_outputs", END)
# MAGIC
# MAGIC     return workflow.compile()
# MAGIC
# MAGIC
# MAGIC class LangGraphChatAgent(ChatAgent):
# MAGIC     def __init__(self, agent: CompiledStateGraph):
# MAGIC         self.agent = agent
# MAGIC
# MAGIC     def predict(
# MAGIC         self,
# MAGIC         messages: list[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> ChatAgentResponse:
# MAGIC         # TODO: Use context and custom_inputs to alter the behavior of the agent
# MAGIC         request = {
# MAGIC             "messages": self._convert_messages_to_dict(messages),
# MAGIC             **({"custom_inputs": custom_inputs} if custom_inputs else {}),
# MAGIC             **({"context": context.model_dump_compat()} if context else {}),
# MAGIC         }
# MAGIC
# MAGIC         response = ChatAgentResponse(messages=[])
# MAGIC         for event in self.agent.stream(request, stream_mode="updates"):
# MAGIC             for node_data in event.values():
# MAGIC                 if not node_data:
# MAGIC                     continue
# MAGIC                 for msg in node_data.get("messages", []):
# MAGIC                     response.messages.append(ChatAgentMessage(**msg))
# MAGIC                 if "custom_outputs" in node_data:
# MAGIC                     response.custom_outputs = node_data["custom_outputs"]
# MAGIC         return response
# MAGIC
# MAGIC     def predict_stream(
# MAGIC         self,
# MAGIC         messages: list[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> Generator[ChatAgentChunk, None, None]:
# MAGIC         # TODO: Use context and custom_inputs to alter the behavior of the agent
# MAGIC         request = {
# MAGIC             "messages": self._convert_messages_to_dict(messages),
# MAGIC             **({"custom_inputs": custom_inputs} if custom_inputs else {}),
# MAGIC             **({"context": context.model_dump_compat()} if context else {}),
# MAGIC         }
# MAGIC
# MAGIC         last_message = None
# MAGIC         last_custom_outputs = None
# MAGIC
# MAGIC         for event in self.agent.stream(request, stream_mode="updates"):
# MAGIC             for node_data in event.values():
# MAGIC                 if not node_data:
# MAGIC                     continue
# MAGIC                 messages = node_data.get("messages", [])
# MAGIC                 custom_outputs = node_data.get("custom_outputs")
# MAGIC
# MAGIC                 for message in messages:
# MAGIC                     if last_message:
# MAGIC                         yield ChatAgentChunk(delta=last_message)
# MAGIC                     last_message = message
# MAGIC                 if custom_outputs:
# MAGIC                     last_custom_outputs = custom_outputs
# MAGIC         if last_message:
# MAGIC             yield ChatAgentChunk(delta=last_message, custom_outputs=last_custom_outputs)
# MAGIC
# MAGIC
# MAGIC # Create the agent object, and specify it as the agent object to use when
# MAGIC # loading the agent back for inference via mlflow.models.set_model()
# MAGIC agent = create_tool_calling_agent(llm, tools, system_prompt)
# MAGIC AGENT = LangGraphChatAgent(agent)
# MAGIC mlflow.models.set_model(AGENT)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test the agent
# MAGIC
# MAGIC Interact with the agent to test its output. Since this notebook called `mlflow.langchain.autolog()` you can view the trace for each step the agent takes.
# MAGIC
# MAGIC Replace this placeholder input with an appropriate domain-specific example for your agent.

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from agent import AGENT

AGENT.predict(
    {
        "messages": [{"role": "user", "content": "Hello!"}],
        "custom_inputs": {"key": "value"},
    }
)

# COMMAND ----------

for event in AGENT.predict_stream(
    {
        "messages": [{"role": "user", "content": "Calculate the final amount on investment (10000 * (1 + 0.05) * 2) in python"}],
        "custom_inputs": {"key": "value"},
    }
):
    print(event, "-----------\n")

# COMMAND ----------

for event in AGENT.predict_stream(
    {
        "messages": [{"role": "user", "content": "Is there any email communication from Steven Marshall?"}],
        "custom_inputs": {"key": "value"},
    }
):
    print(event, "-----------\n")

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Log the agent as an MLflow model
# MAGIC
# MAGIC Log the agent as code from the `agent.py` file. See [MLflow - Models from Code](https://mlflow.org/docs/latest/models.html#models-from-code).
# MAGIC
# MAGIC ### Enable automatic authentication for Databricks resources
# MAGIC For the most common Databricks resource types, Databricks supports and recommends declaring resource dependencies for the agent upfront during logging. This enables automatic authentication passthrough when you deploy the agent. With automatic authentication passthrough, Databricks automatically provisions, rotates, and manages short-lived credentials to securely access these resource dependencies from within the agent endpoint.
# MAGIC
# MAGIC To enable automatic authentication, specify the dependent Databricks resources when calling `mlflow.pyfunc.log_model().`
# MAGIC
# MAGIC   - **TODO**: If your Unity Catalog tool queries a [vector search index](docs link) or leverages [external functions](docs link), you need to include the dependent vector search index and UC connection objects, respectively, as resources. See docs ([AWS](https://docs.databricks.com/generative-ai/agent-framework/log-agent.html#specify-resources-for-automatic-authentication-passthrough) | [Azure](https://learn.microsoft.com/azure/databricks/generative-ai/agent-framework/log-agent#resources)).
# MAGIC
# MAGIC

# COMMAND ----------

import mlflow
from agent import tools, LLM_ENDPOINT_NAME
from databricks_langchain import VectorSearchRetrieverTool
from mlflow.models.resources import DatabricksFunction, DatabricksServingEndpoint
from unitycatalog.ai.langchain.toolkit import UnityCatalogTool

resources = [DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT_NAME)]
for tool in tools:
    if isinstance(tool, VectorSearchRetrieverTool):
        resources.extend(tool.resources)
    elif isinstance(tool, UnityCatalogTool):
        resources.append(DatabricksFunction(function_name=tool.uc_function_name))


with mlflow.start_run():
    logged_agent_info = mlflow.pyfunc.log_model(
        artifact_path="agent",
        python_model="agent.py",
        pip_requirements=[
            "mlflow",
            "langchain",
            "langgraph==0.2.74",
            "databricks-langchain",
            "unitycatalog-langchain[databricks]",
            "pydantic",
        ],
        resources=resources,
    )

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Pre-deployment agent validation
# MAGIC Before registering and deploying the agent, perform pre-deployment checks using the [mlflow.models.predict()](https://mlflow.org/docs/latest/python_api/mlflow.models.html#mlflow.models.predict) API. See Databricks documentation ([AWS](https://docs.databricks.com/en/machine-learning/model-serving/model-serving-debug.html#validate-inputs) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/machine-learning/model-serving/model-serving-debug#before-model-deployment-validation-checks)).

# COMMAND ----------

mlflow.models.predict(
    model_uri=f"runs:/{logged_agent_info.run_id}/agent",
    input_data={"messages": [{"role": "user", "content": "Hello!"}]},
    env_manager="uv",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Register the model to Unity Catalog
# MAGIC
# MAGIC Before you deploy the agent, you must register the agent to Unity Catalog.
# MAGIC
# MAGIC - **TODO** Update the `catalog`, `schema`, and `model_name` below to register the MLflow model to Unity Catalog.

# COMMAND ----------

mlflow.set_registry_uri("databricks-uc")

# TODO: define the catalog, schema, and model name for your UC model
catalog = "sarbanimaiti_catalog"
schema = "dbdemo_agent"
model_name = "lgtc_custsch_Finagnt"
UC_MODEL_NAME = f"{catalog}.{schema}.{model_name}"

# register the model to UC
uc_registered_model_info = mlflow.register_model(
    model_uri=logged_agent_info.model_uri, name=UC_MODEL_NAME
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Deploy the agent

# COMMAND ----------



# from databricks import agents
# agents.deploy(UC_MODEL_NAME, uc_registered_model_info.version, tags = {"endpointSource": "docs"})

# catalog = "sarbanimaiti_catalog"
# schema = "dbdemo_agent"
model_name = "lgtc_custsch_Finagnt"
UC_MODEL_NAME = "sarbanimaiti_catalog.dbdemo_agent.lgtc_custsch_Finagnt"


from databricks import agents
agents.deploy(UC_MODEL_NAME, 3, tags = {"endpointSource": "docs"})

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next steps
# MAGIC
# MAGIC After your agent is deployed, you can chat with it in AI playground to perform additional checks, share it with SMEs in your organization for feedback, or embed it in a production application. See Databricks documentation ([AWS](https://docs.databricks.com/en/generative-ai/deploy-agent.html) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/deploy-agent)).

# COMMAND ----------

# MAGIC %md
# MAGIC #### Test Index

# COMMAND ----------

# DBTITLE 1,Testing...Creating or Retrieving Index for Customer Emails
import databricks.sdk.service.catalog as c
from databricks.vector_search.client import VectorSearchClient
VECTOR_SEARCH_ENDPOINT_NAME = "one-env-shared-endpoint-1"
vsc = VectorSearchClient(disable_notice=True)

# Where we want to store our index
vs_index_fullname = f"{catalog}.{db}.cust_emails_idx"
#embedding_model_endpoint = "databricks-gte-large-en"

# index = vsc.create_delta_sync_index(
#   endpoint_name=VECTOR_SEARCH_ENDPOINT_NAME,
#   source_table_name=f"{catalog}.{db}.customer_emails", 
#   index_name=vs_index_fullname,
#   pipeline_type="TRIGGERED",
#   primary_key='transaction_id',
#   embedding_source_column="email_content",
#   embedding_model_endpoint_name= embedding_model_endpoint)
index = vsc.get_index(VECTOR_SEARCH_ENDPOINT_NAME, vs_index_fullname)

# if not index_exists(vsc, VECTOR_SEARCH_ENDPOINT_NAME, vs_index_fullname):
#   print(f"Creating index {vs_index_fullname} on endpoint {VECTOR_SEARCH_ENDPOINT_NAME}...")
#   index = vsc.create_delta_sync_index(
#     endpoint_name=VECTOR_SEARCH_ENDPOINT_NAME,
#     source_table_name=f"{catalog}.{db}.customer_emails", 
#     index_name=vs_index_fullname,
#     pipeline_type="TRIGGERED",
#     primary_key='transaction_id',
#     embedding_source_column="email_content",
#     embedding_model_endpoint_name= embedding_model_endpoint
#   )
# else:
#   print(f"Grabbing existing index {vs_index_fullname} on endpoint {VECTOR_SEARCH_ENDPOINT_NAME}...")
#   index = vsc.get_index(VECTOR_SEARCH_ENDPOINT_NAME, vs_index_fullname)

# COMMAND ----------


index.similarity_search(
    columns=['customer_id', 'transaction_id', 'email_content'],
    query_text='83214a7c-d15f-4d5c-8708-c25058fd3423',
    query_type="hybrid"
)

# COMMAND ----------

