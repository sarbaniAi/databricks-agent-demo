# Databricks notebook source
# MAGIC %md 
# MAGIC # Mosaic AI Agent Framework: Author a custom schema OpenAI agent
# MAGIC
# MAGIC This notebook demonstrates how to author a OpenAI agent that's compatible with Mosaic AI Agent Framework features. In this notebook you learn to:
# MAGIC - Author a tool-calling OpenAI agent wrapped with `ChatAgent` with custom inputs and outputs
# MAGIC - Manually test the agent's output
# MAGIC - Log and deploy the agent
# MAGIC
# MAGIC To learn more about authoring an agent using Mosaic AI Agent Framework, see Databricks documentation ([AWS](https://docs.databricks.com/aws/generative-ai/agent-framework/author-agent) | [Azure](https://learn.microsoft.com/azure/databricks/generative-ai/agent-framework/create-chat-model)).
# MAGIC
# MAGIC ## Prerequisites
# MAGIC
# MAGIC - Address all `TODO`s in this notebook.

# COMMAND ----------

# MAGIC %pip install -U -qqqq mlflow openai databricks-agents uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ## Define the agent in code
# MAGIC Define the agent code in a single cell below. This lets you easily write the agent code to a local Python file, using the `%%writefile` magic command, for subsequent logging and deployment.
# MAGIC

# COMMAND ----------

# MAGIC %%writefile agent.py
# MAGIC from typing import Any, Generator, Optional
# MAGIC
# MAGIC import mlflow
# MAGIC from databricks.sdk import WorkspaceClient
# MAGIC from mlflow.entities import SpanType
# MAGIC from mlflow.pyfunc.model import ChatAgent
# MAGIC from mlflow.types.agent import (
# MAGIC     ChatAgentChunk,
# MAGIC     ChatAgentMessage,
# MAGIC     ChatAgentResponse,
# MAGIC     ChatContext,
# MAGIC )
# MAGIC
# MAGIC mlflow.openai.autolog()
# MAGIC
# MAGIC # TODO: Replace with your model serving endpoint
# MAGIC LLM_ENDPOINT_NAME = "databricks-meta-llama-3-3-70b-instruct"
# MAGIC
# MAGIC
# MAGIC class CustomChatAgent(ChatAgent):
# MAGIC     def __init__(self):
# MAGIC         self.workspace_client = WorkspaceClient()
# MAGIC         self.client = self.workspace_client.serving_endpoints.get_open_ai_client()
# MAGIC         self.llm_endpoint = LLM_ENDPOINT_NAME
# MAGIC
# MAGIC     @mlflow.trace(span_type=SpanType.AGENT)
# MAGIC     def predict(
# MAGIC         self,
# MAGIC         messages: list[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> ChatAgentResponse:
# MAGIC         resp = self.client.chat.completions.create(
# MAGIC             model=self.llm_endpoint,
# MAGIC             messages=self._convert_messages_to_dict(messages),
# MAGIC         )
# MAGIC         custom_output_message = ChatAgentMessage(
# MAGIC             **{"role": "assistant", "content": "Echoing back custom inputs."}
# MAGIC         )
# MAGIC         return ChatAgentResponse(
# MAGIC             messages=[
# MAGIC                 ChatAgentMessage(**resp.choices[0].message.to_dict()),
# MAGIC                 custom_output_message,
# MAGIC             ],
# MAGIC             custom_outputs=custom_inputs,
# MAGIC         )
# MAGIC
# MAGIC     @mlflow.trace(span_type=SpanType.AGENT)
# MAGIC     def predict_stream(
# MAGIC         self,
# MAGIC         messages: list[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> Generator[ChatAgentChunk, None, None]:
# MAGIC         for chunk in self.client.chat.completions.create(
# MAGIC             model=self.llm_endpoint,
# MAGIC             messages=self._convert_messages_to_dict(messages),
# MAGIC             stream=True,
# MAGIC         ):
# MAGIC             if not chunk.choices or not chunk.choices[0].delta.content:
# MAGIC                 continue
# MAGIC
# MAGIC             yield ChatAgentChunk(
# MAGIC                 delta=ChatAgentMessage(
# MAGIC                     **{
# MAGIC                         "role": "assistant",
# MAGIC                         "content": chunk.choices[0].delta.content,
# MAGIC                         "id": chunk.id,
# MAGIC                     }
# MAGIC                 )
# MAGIC             )
# MAGIC         yield ChatAgentChunk(
# MAGIC             delta=ChatAgentMessage(
# MAGIC                 role="assistant",
# MAGIC                 content="Echoing back custom inputs.",
# MAGIC             ),
# MAGIC             custom_outputs=custom_inputs,
# MAGIC         )
# MAGIC
# MAGIC
# MAGIC from mlflow.models import set_model
# MAGIC
# MAGIC AGENT = CustomChatAgent()
# MAGIC set_model(AGENT)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test the agent
# MAGIC
# MAGIC Interact with the agent to test its output. Since we manually traced methods within `ChatAgent`, you can view the trace for each step the agent takes, with any LLM calls made via the OpenAI SDK automatically traced by autologging.
# MAGIC
# MAGIC Replace this placeholder input with an appropriate domain-specific example for your agent.

# COMMAND ----------



# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from agent import AGENT

AGENT.predict(
    {
        "messages": [{"role": "user", "content": "What is 5+5?"}],
        "custom_inputs": {"key": "value"},
    }
)

# COMMAND ----------

for event in AGENT.predict_stream(
    {
        "messages": [{"role": "user", "content": "What is 5+5?"}],
        "custom_inputs": {"key": "value"},
    }
):
    print(event, "-----------\n")

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Log the `agent` as an MLflow model
# MAGIC Log the agent as code from the `agent.py` file. See [MLflow - Models from Code](https://mlflow.org/docs/latest/models.html#models-from-code).

# COMMAND ----------

import mlflow
from mlflow.models.resources import DatabricksServingEndpoint
from agent import LLM_ENDPOINT_NAME

with mlflow.start_run():
    logged_agent_info = mlflow.pyfunc.log_model(
        artifact_path="agent",
        python_model="agent.py",
        pip_requirements=[
            "mlflow",
            "openai",
            "databricks-sdk",
        ],
        resources=[DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT_NAME)]
    )

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Pre-deployment agent validation
# MAGIC Before registering and deploying the agent, perform pre-deployment checks using the [mlflow.models.predict()](https://mlflow.org/docs/latest/python_api/mlflow.models.html#mlflow.models.predict) API. See Databricks documentation ([AWS](https://docs.databricks.com/en/machine-learning/model-serving/model-serving-debug.html#validate-inputs) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/machine-learning/model-serving/model-serving-debug#before-model-deployment-validation-checks)).

# COMMAND ----------

mlflow.models.predict(
    model_uri=f"runs:/{logged_agent_info.run_id}/agent",
    input_data={"messages": [{"role": "user", "content": "Hello!"}]},
    env_manager="uv"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Register the model to Unity Catalog
# MAGIC
# MAGIC Before you deploy the agent, you must register the agent to Unity Catalog.
# MAGIC
# MAGIC - **TODO** Update the `catalog`, `schema`, and `model_name` below to register the MLflow model to Unity Catalog.

# COMMAND ----------

mlflow.set_registry_uri("databricks-uc")

# TODO: define the catalog, schema, and model name for your UC model
catalog = "sarbanimaiti_catalog"
schema = "dbdemo_agent"
model_name = "openai_pyfunc_cust_sch_agnt"
UC_MODEL_NAME = f"{catalog}.{schema}.{model_name}"

# register the model to UC
uc_registered_model_info = mlflow.register_model(model_uri=logged_agent_info.model_uri, name=UC_MODEL_NAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Deploy the agent

# COMMAND ----------

from databricks import agents

agents.deploy(UC_MODEL_NAME, uc_registered_model_info.version, tags={"endpointSource": "docs"})

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next steps
# MAGIC
# MAGIC After your agent is deployed, you can chat with it in AI playground to perform additional checks, share it with SMEs in your organization for feedback, or embed it in a production application. See Databricks documentation ([AWS](https://docs.databricks.com/en/generative-ai/deploy-agent.html) | [Azure](https://learn.microsoft.com/en-us/azure/databricks/generative-ai/deploy-agent)).